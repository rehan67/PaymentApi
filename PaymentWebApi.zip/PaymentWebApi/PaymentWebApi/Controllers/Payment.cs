﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PaymentWebApi.Models;
using PaymentWebApi.Repository.IRepo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PaymentWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Payment : ControllerBase
    {
        private readonly ICheapPaymentGateway cheapPaymentGateway;
        private readonly IExpensivesPaymentGateway expensivesPaymentGateway;

        public Payment(ICheapPaymentGateway cheapPaymentGateway,IExpensivesPaymentGateway expensivesPaymentGateway)
        {
            this.cheapPaymentGateway = cheapPaymentGateway;
            this.expensivesPaymentGateway = expensivesPaymentGateway;
        }
        public IActionResult ProcessPayment(PaymentModel model)
        {

            PaymentState result = new PaymentState();
            if (!ModelState.IsValid) return BadRequest();
            if (ModelState.IsValid)
            {
                if(model.Amount < 20)
                {
                   var cheapPayment =  cheapPaymentGateway.CheapPayment();
                    if (cheapPayment.Isprocess)
                    {
                        return Ok();
                    }else if (cheapPayment.Isfailed)
                    {
                        return StatusCode(500);

                    }
                }
                else if(model.Amount >=21 && model.Amount <= 500)
                {
                   var expensivepayment =  expensivesPaymentGateway.ExpensivePayment();

                    if (expensivepayment.Isprocess)
                    {
                        return Ok();
                    }
                    else if (expensivepayment.Isfailed)
                    {
                        return StatusCode(500);

                    }

                }
                else if(model.Amount > 500)
                {
                  var paymentstate =   expensivesPaymentGateway.PremiamPayment();

                    if (paymentstate.Isprocess)
                    {
                        return Ok();
                    } else  if (paymentstate.Isfailed)
                    {
                        int retries = 3;
                        while (retries > 0)
                        {
                          var paystate =   expensivesPaymentGateway.PremiamPayment();
                            if (paystate.Isprocess)
                            {
                                retries = 0;
                            }
                            else
                            {
                                retries--;
                            }
                        }
                    }
                }

                return Ok();
            }


           
            return Ok("something missing");
        }
    }
}
