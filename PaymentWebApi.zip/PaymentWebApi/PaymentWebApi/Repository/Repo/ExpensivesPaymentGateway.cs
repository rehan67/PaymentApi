﻿using PaymentWebApi.Models;
using PaymentWebApi.Repository.IRepo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PaymentWebApi.Repository.Repo
{
    public class ExpensivesPaymentGateway : IExpensivesPaymentGateway
    {
        public PaymentState ExpensivePayment()
        {
            throw new NotImplementedException();
        }

        public PaymentState PremiamPayment()
        {
            throw new NotImplementedException();
        }
    }
}
