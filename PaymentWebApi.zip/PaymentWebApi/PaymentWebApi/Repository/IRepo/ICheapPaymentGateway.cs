﻿using PaymentWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PaymentWebApi.Repository.IRepo
{
   public interface ICheapPaymentGateway
    {
        PaymentState CheapPayment();
    }
}
