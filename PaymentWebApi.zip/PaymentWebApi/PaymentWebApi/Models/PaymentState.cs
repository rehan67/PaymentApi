﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PaymentWebApi.Models
{
    public class PaymentState
    {
        public bool Ispending { get; set; }
        public bool Isprocess { get; set; }
        public bool Isfailed { get; set; }
    }
}
